//
//  AppAssets.swift
//  Test Playground
//
//  Created by  Кирилл on 3/6/19.
//

import UIKit

enum AppAssets {
    static var settingsIcon: UIImage? {
        return UIImage(named: "SettingsIcon")
    }
}
